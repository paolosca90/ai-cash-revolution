# AI Trading Bot - Portable Version

## Quick Start:
1. Double-click 'run.bat' to start
2. Follow the automated setup
3. Your MT5 will be connected automatically

## Requirements:
- Python 3.7+ (will install packages automatically)
- MetaTrader 5 (will guide installation if missing)
- Windows 10/11

## What it does:
- Installs all Python dependencies automatically
- Finds or helps install MT5
- Configures bridge server
- Connects to your trading account
- Starts background service

## Support:
Open the web app at: https://ai-cash-revolution-frontend.vercel.app
